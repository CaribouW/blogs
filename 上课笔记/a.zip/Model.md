## Model

dvaJS框架学习

#### 目的

将页面自身的`state`上升到所有组件平行的一个`state namespace`

利用类似于**控制反转**的技术，将`state`注入到组件的`Prop`中